package com.medical.spring.service;

import com.alibaba.fastjson.JSONObject;

import java.util.*;

/**
 * @Author LJX
 * @TIME 2021-10-27 9:47
 * @PROJECT spring
 * created by Intellij IDEA
 * Description
 */
public interface DemoService {

    JSONObject demoS();

}
