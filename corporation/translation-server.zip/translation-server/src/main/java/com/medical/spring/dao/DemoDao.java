package com.medical.spring.dao;

import com.alibaba.fastjson.JSONObject;
import java.util.*;

/**
 * @Author LJX
 * @TIME 2021-10-27 9:59
 * @PROJECT spring
 * created by Intellij IDEA
 * Description
 */
public interface DemoDao {


    List<JSONObject>demo();

}
