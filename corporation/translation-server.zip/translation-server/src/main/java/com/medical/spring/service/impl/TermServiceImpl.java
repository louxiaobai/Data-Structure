package com.medical.spring.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.medical.spring.dao.TermMapper;
import com.medical.spring.service.TermService;
import com.medical.spring.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

/**
 * @author lqw
 * @date 2021/11/3-9:53 上午
 */
@Service("termservice")
public class TermServiceImpl implements TermService {

    @Autowired
    private TermMapper termMapper;
    @Override
    public List<JSONObject> getTerm() {

        return termMapper.getTerm() ;

    }
    @Override
    public JSONObject getTermByid(int id) {
        return  CommonUtil.successJson(termMapper.getTermByid(id));
    }
    @Override
    public int addTerm(JSONObject term) {
        return termMapper.addTerm(term);
    }
    @Override
    public int deleteTerm(int id) {
        return termMapper.deleteTerm(id);
    }
    @Override
    public int updateTerm(JSONObject term) {
        return termMapper.updateTerm(term);
    }
}