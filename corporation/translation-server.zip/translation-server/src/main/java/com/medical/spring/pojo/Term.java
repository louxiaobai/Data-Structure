package com.medical.spring.pojo;

import java.util.Date;

/**
 * @author lqw
 * @date 2021/11/2-11:06 上午
 */
public class Term {

    private int id;//主键
    private int term_db_id;//所属术语库id
    private String original;//
    private String translation;
    private int state;//0.未审核 1.已审核
    private String update_user;//-1为系统，其他为用户
    private Date update_date;



}