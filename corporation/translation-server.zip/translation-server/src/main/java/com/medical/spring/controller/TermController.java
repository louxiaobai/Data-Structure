package com.medical.spring.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.medical.spring.service.TermService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.*;
import java.util.List;
import java.util.Map;
/**
 * @author lqw
 * @date 2021/11/16-10:13 上午
 */
@RestController
@RequestMapping("/term")
@EnableAutoConfiguration
public class TermController {
    @Autowired
    private TermService termService;
    @GetMapping("/getTerms")
    public List<JSONObject> getTerms(){
        return termService.getTerm();
    }
    @GetMapping(value="getTermById/{id}")
    public JSONObject getTermById(@PathVariable int id){
        return termService.getTermByid(id);
    }
    @PostMapping("/updateTerm")
    public int updateTerm(@RequestBody JSONObject term){

        int i = termService.updateTerm(term);
        return i;
    }
    @GetMapping(value="/deleteTermById/{id}")
    public int deleteTermById(@PathVariable int id){
        int i = termService.deleteTerm(id);
        return i;
    }
    @PostMapping("/addTerm")
    public int addTerm (@RequestBody JSONObject term ) {
        return termService.addTerm(term);
    }
}