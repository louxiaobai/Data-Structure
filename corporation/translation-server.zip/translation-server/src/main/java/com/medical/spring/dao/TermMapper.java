package com.medical.spring.dao;

import com.alibaba.fastjson.JSONObject;

import java.util.List;

/**
 * @author lqw
 * @date 2021/11/3-10:49 上午
 */
public interface TermMapper {

    //得到全部信息
    List<JSONObject> getTerm();
    //根据id查询信息
    JSONObject getTermByid(int id);
    //对术语库进行添加信息
    int addTerm(JSONObject term);
    //对术语库进行删除信息
    int deleteTerm(int id);
    //对术语库的信息进行修改操作
    int updateTerm(JSONObject term);
}
