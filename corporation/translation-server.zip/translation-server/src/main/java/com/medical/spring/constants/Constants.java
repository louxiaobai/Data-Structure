package com.medical.spring.constants;

import java.util.HashMap;
import java.util.Map;

/**
 * @author: lsc
 * @description: 通用常量类, 单个业务的常量请单开一个类, 方便常量的分类管理
 * @date: 2021/3/10 10:31
 */
public class Constants {

	public static final String SUCCESS_CODE = "0";
	public static final String SUCCESS_MSG = "请求成功";

	public static final String AWAIT_CODE = "100";
	public static final String AWAIT_MSG = "请等待";

	/**
	 * 登录异常存放值
	 */
	public static final Integer NO_AUTHENTICATION = 20010;



}
