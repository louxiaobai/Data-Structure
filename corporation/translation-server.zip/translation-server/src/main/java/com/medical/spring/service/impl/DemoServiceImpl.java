package com.medical.spring.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.medical.spring.dao.DemoDao;
import com.medical.spring.service.DemoService;
import com.medical.spring.util.CommonUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @Author LJX
 * @TIME 2021-10-27 9:58
 * @PROJECT spring
 * created by Intellij IDEA
 * Description
 */
@Service("demoservice")
public class DemoServiceImpl implements DemoService {

    @Autowired
    private DemoDao d;

    @Override
    public JSONObject demoS() {
        return CommonUtil.successJson(d.demo());
    }
}
