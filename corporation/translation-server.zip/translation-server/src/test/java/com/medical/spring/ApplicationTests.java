package com.medical.spring;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import com.medical.spring.dao.TermMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@SpringBootTest
public class ApplicationTests {

    @Autowired
    TermMapper Mapper;
    @Test
    public void contextLoads() {
        List<JSONObject> term = Mapper.getTerm();
        for (JSONObject object : term) {
            System.out.println(object);
        }
    }
    @Test
    public void getTermByid(){
        JSONObject termByid = Mapper.getTermByid(11);
        System.out.println(termByid);
    }
    @Test
    public void inserObject(){
        Map map=new HashMap();
        map.put("term_db_id",1);
        map.put("original", "s");
        map.put("original", "s");
        map.put("translation", "s2");
        map.put("state", "1");
        map.put("update_user", "11");
        map.put("update_date", "2012-01-12");
        String  param= JSON.toJSONString(map);
        JSONObject obj=JSON.parseObject(param);
        int add = Mapper.addTerm(obj);
        System.out.println(add);
    }
    @Test
    public void deleteObject(){

         int delete = Mapper.deleteTerm(1439);
         System.out.println(delete);

     }
    @Test
    public void updateObject(){

        Map map=new HashMap();
        map.put("id", 11111);
        map.put("term_db_id",1);
        map.put("original", "test");
        map.put("original", "test");
        map.put("translation", "test");
        map.put("state", 1);
        map.put("update_user", 11);
        map.put("update_date", "2012-02-12");
        String  param= JSON.toJSONString(map);
        JSONObject obj=JSON.parseObject(param);
        int i = Mapper.updateTerm(obj);
        if (i>0){
            System.out.println("修改成功!");
        }else{
            System.out.println("修改失败");
        }



    }
    @Test
    public void test(){
        String text="<group>\n" +
                "                <sdl:cxts>\n" +
                "                    <sdl:cxt id=\"57\" />\n" +
                "                    <sdl:cxt id=\"45\" />\n" +
                "                </sdl:cxts>\n" +
                "                <trans-unit id=\"ab598035-b388-44ac-bf33-085c6dae487f\">\n" +
                "                    <source>\n" +
                "                    <g id=\"379\">1. INTRODUCTION</g>\n" +
                "                    </source>\n" +
                "                    <seg-source>\n" +
                "                        <g id=\"379\">\n" +
                "                            <mrk mtype=\"seg\" mid=\"49\">1.</mrk>\n" +
                "                            <mrk mtype=\"seg\" mid=\"50\">INTRODUCTION</mrk>\n" +
                "                        </g>\n" +
                "                    </seg-source>\n" +
                "                    <target>\n" +
                "                        <g id=\"379\">\n" +
                "                            <mrk mtype=\"seg\" mid=\"49\">1.</mrk>\n" +
                "                            <mrk mtype=\"seg\" mid=\"50\">测试翻译结果</mrk>\n" +
                "                        </g>\n" +
                "                    </target>\n" +
                "                    <sdl:seg-defs>\n" +
                "                        <sdl:seg id=\"49\" locked=\"true\">\n" +
                "                            <sdl:rep id=\"kvDb2IoakeVV5COiU7UJZ5iVYjA=\" />\n" +
                "                            <sdl:prev-origin>\n" +
                "                                <sdl:rep id=\"kvDb2IoakeVV5COiU7UJZ5iVYjA=\" />\n" +
                "                                <sdl:value key=\"SegmentIdentityHash\">kvDb2IoakeVV5COiU7UJZ5iVYjA=</sdl:value>\n" +
                "                            </sdl:prev-origin>\n" +
                "                            <sdl:value key=\"SegmentIdentityHash\">kvDb2IoakeVV5COiU7UJZ5iVYjA=</sdl:value>\n" +
                "                        </sdl:seg>\n" +
                "                        <sdl:seg id=\"50\" locked=\"true\">\n" +
                "                            <sdl:rep id=\"2UttsJllA6H20fa/iPIfC744M24=\" />\n" +
                "                            <sdl:prev-origin>\n" +
                "                                <sdl:rep id=\"2UttsJllA6H20fa/iPIfC744M24=\" />\n" +
                "                                <sdl:value key=\"SegmentIdentityHash\">2UttsJllA6H20fa/iPIfC744M24=</sdl:value>\n" +
                "                            </sdl:prev-origin>\n" +
                "                            <sdl:value key=\"SegmentIdentityHash\">2UttsJllA6H20fa/iPIfC744M24=</sdl:value>\n" +
                "                        </sdl:seg>\n" +
                "                    </sdl:seg-defs>\n" +
                "                </trans-";




    }




}
